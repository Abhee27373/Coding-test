package com.todo.test;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.todo.controller.TODORestController;
import com.todo.service.TODOService;
import com.todo.viewobjects.TODO;

//@RunWith(SpringJUnit4ClassRunner.class)
@WebMvcTest(TODORestController.class) 
@RunWith(SpringRunner.class)
//@SpringBootTest(classes={GuestServicesApplication.class})
public class TODOServicesApplicationTests {

	
	@Autowired
	private WebApplicationContext context;
	
	
	
	@Autowired
	private MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders
	            .webAppContextSetup(context)
	            .apply(SecurityMockMvcConfigurers.springSecurity())
	            .build();
	}

	@MockBean
	private TODOService todoService;

	@Test
	public void testListAllTodos() throws Exception {
		TODO todo1 = new TODO();
		todo1.setId(111);
		todo1.setTitle("Title1");
		todo1.setDescription("AAAA");
		todo1.setDueDate(new Date());;
		
		
		TODO todo2 = new TODO();
		todo1.setId(222);
		todo1.setTitle("Title2");
		todo1.setDescription("BBBB");
		todo1.setDueDate(new Date());
	

		TODO todo3 = new TODO();
		todo1.setId(222);
		todo1.setTitle("Title3");
		todo1.setDescription("CCCC");
		todo1.setDueDate(new Date());
		
	

		when(todoService.listAllTodos()).thenReturn(Arrays.asList(todo1, todo2, todo3));

		mockMvc.perform(get("/todo/all")).andExpect(status().is4xxClientError())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$", hasSize(3)))
				.andExpect(jsonPath("$[0].id", is(11))).andExpect(jsonPath("$[0].description", is("AAAA")))
				.andExpect(jsonPath("$[1].id", is(22))).andExpect(jsonPath("$[1].description", is("BBBB")))
				.andExpect(jsonPath("$[1].id", is(33))).andExpect(jsonPath("$[1].description", is("CCCC")));

		verify(todoService, times(1)).listAllTodos();
		verifyNoMoreInteractions(todoService);
	}
}
