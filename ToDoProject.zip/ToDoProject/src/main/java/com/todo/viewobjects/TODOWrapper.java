package com.todo.viewobjects;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;

@ApiModel
public class TODOWrapper implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<TODO>todoList;
	
	public List<TODO> getTodoList() {
		return todoList;
	}
	public void setTodoList(List<TODO> todoList) {
		this.todoList = todoList;
	}
	
	
	
}
