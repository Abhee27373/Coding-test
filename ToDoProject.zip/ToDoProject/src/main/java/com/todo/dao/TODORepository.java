package com.todo.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.todo.viewobjects.TODO;

@RepositoryRestResource
public interface TODORepository extends CrudRepository<TODO, Integer>{
}