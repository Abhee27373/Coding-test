package com.todo.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.todo.dao.TODORepository;
import com.todo.viewobjects.TODO;
/**
 * 
 * @author vinee
 *
 */
@Component
@ComponentScan("com.todo.service")
@Qualifier("todoService")
public class TODOServiceImpl implements TODOService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private TODORepository todoRepository;

    @Autowired
    public void setProductRepository(TODORepository todoRepository) {
        this.todoRepository = todoRepository;
    }

    @Override
    public Iterable<TODO> listAllTodos() {
        logger.debug("listAllTodos called");
        return todoRepository.findAll();
    }

    @Override
    public TODO getTodoById(Integer id) {
        logger.debug("gettodoById called");
        return todoRepository.findOne(id);
    }

    @Override
    public TODO saveTodo(TODO todo) {
        logger.debug("saveTodo called");
        return todoRepository.save(todo);
    }

    @Override
    public void deleteTodo(Integer id) {
        logger.debug("deleteProduct called");
        todoRepository.delete(id);
    }


}
