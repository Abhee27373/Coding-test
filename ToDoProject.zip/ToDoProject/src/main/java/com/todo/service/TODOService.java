package com.todo.service;

import com.todo.viewobjects.TODO;


public interface TODOService {
    Iterable<TODO> listAllTodos();

    TODO getTodoById(Integer id);

    TODO saveTodo(TODO todo);

    void deleteTodo(Integer id);
    
}
	