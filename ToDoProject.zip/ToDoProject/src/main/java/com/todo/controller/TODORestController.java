
package com.todo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.todo.dao.TODORepository;
import com.todo.service.TODOService;
import com.todo.viewobjects.TODO;
import com.todo.viewobjects.TODOWrapper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@Api(value = "todo", description = "Endpoint for todo sample app")
@RestController
@RequestMapping("/todo")
public class TODORestController {



	@Autowired
	private TODOService todoService;

	/**
	 * Fetch a list of TODo Items
	 * @return a list of TODO 
	 */
	
    @RequestMapping(path="/all", method = RequestMethod.GET, produces = "application/json")
    @ApiOperation(value = "Fetch all Todo Items")
    @ApiResponses(value = { 
            @ApiResponse(code = 200, message = "Success", response = TODO.class),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Server Error")}) 
   
    public List<TODO> listAllTodos() {
    	
    	List<TODO> todoList = (List<TODO>) todoService.listAllTodos();
    	return todoList;
    }
    
    /***
     * 
     * @param id
     * @return
     */
    
    @RequestMapping(path = "/{id}", 
    				method = RequestMethod.GET)
    @ApiOperation(value = "Fetch a Todo by Id")
    @ApiResponses(value = { 
            @ApiResponse(code = 200, message = "Success", response = TODO.class),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Server Error")}) 
    public TODO guest(@PathVariable Integer id) {
    	return todoService.getTodoById(id);
    }
    
    /**
     * 
     * @param todoWrapper
     * @return
     */
    @RequestMapping(path = "/add",
    		method = RequestMethod.POST,
    		consumes =  MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Add a ToDo")
    @ApiResponses(value = { 
    		@ApiResponse(code = 201, message = "Success", response = TODO.class),
    		@ApiResponse(code = 404, message = "Not Found"),
    		@ApiResponse(code = 500, message = "Server Error")}) 
    public List<TODO> add(@RequestBody TODOWrapper todoWrapper) {
    	
    	List<TODO>savedToDoList = null;
    	if(null!= todoWrapper && !todoWrapper.getTodoList().isEmpty()) {
    		savedToDoList =  new ArrayList<TODO>();
    	}
    	for(TODO todoTemp :todoWrapper.getTodoList()) {
    		TODO savedToDo =  todoService.saveTodo(todoTemp);
    		savedToDoList.add(savedToDo);
    	}
    	return savedToDoList;
    }

 /**
  * 
  * @param id
  * @param todo
  * @return
  */
    
    @ApiOperation(value = "Update a ToDo")
    @ApiResponses(value = { 
            @ApiResponse(code = 200, message = "Success", response = TODO.class),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Server Error")}) 
    @RequestMapping(value = "/update/{id}", method = RequestMethod.PATCH, produces = "application/json")
    public TODO updateProduct(@PathVariable Integer id, @RequestBody TODO todo){
        TODO storedTodo = todoService.getTodoById(id);
        storedTodo.setTitle(todo.getTitle());
        storedTodo.setDescription(todo.getDescription());
        storedTodo.setDueDate(todo.getDueDate());
        return todoService.saveTodo(storedTodo);
       
    }

    
   
    @RequestMapping(path = "/delete/{id}", 
			method = RequestMethod.DELETE)
    @ApiOperation(value = "Delete a ToDo")
    @ApiResponses(value = { 
            @ApiResponse(code = 200, message = "Success", response = TODO.class),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Server Error")}) 
    public void delete(@PathVariable Integer id) {
    	todoService.deleteTodo(id);
    }


}
